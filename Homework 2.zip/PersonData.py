class PersonData:
    """Creates a class PersonData with instance age, spouse, and children."""
    def __init__(self, age=0, spouse=None, children=0):
        """ this initialises a class of PersonData and sets age to 0, spouse to none, and children to 0."""
        self.age = age
        self.children = children
        self.spouse = spouse
    

    def __str__(self):   
        """Converts integer age to String and returns the age of the person as a String."""
        return "A " + str(self.age) + " year old person"

    def birthday(self):
        """Increase the age of the person by 1."""
        self.age += 1
    

    def print_data(self):
        """Prints the age, children, and spouse in string with 10 spaces in between."""
        print(
            "%s,%10s,%10s" %
            (str(
                self.age), str(
                self.children), self.spouse))
    

    def marries(self, spouse):
        """This defines married spouse of each PersonData."""
        if not self.spouse:
            self.spouse = spouse
        else:
            raise Exception("Spouse exists: " + self.spouse)
    

    def divorces(self): 
        """Divorces method check if Self.spouse is None.
    
        if no married spouse is identified then none is recorded. 
        AttributeError of not married or divorce impossible is raised. 
        """
        if self.spouse:
            self.spouse = None
        else:
            raise AttributeError("Not married, divorce impossible")
   

    def new_child(self):
        """New children is defined and the count of children is increased by 1."""
        self.children += 1
    

    
if __name__ == "__main__":
    """Sample output to run with PersonData."""
    p1 = PersonData(31, spouse="Sue", children=2)
    print(p1)
    p1.print_data()
    p1.birthday()
    p1.new_child()
    p1.divorces()
    p1.print_data()
    p1.marries("Pam")
    try:
        p1.marries("Sue")
    except Exception as detail:
        print(detail)
    try:
        p1.divorces()
        p1.divorces()
    except AttributeError as detail:
        print(detail)
    p2 = PersonData(39)
    p2.print_data()
