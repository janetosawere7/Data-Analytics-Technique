""" Import from PersonData to retrieve information of each person to the Class Population."""

from PersonData import PersonData

class Population():
    """This creates a class population."""

    # Dictionary for each person is created to input each persons information from PersonData.
    people = {}
     
    def __str__(self):
        """This returns a string of the number of persons recorded."""
        return "There are now " + str(len(self.people)) + " persons recorded."
    

    def len_dic(self):
        """This returns the number of persons recorded."""
        return("There are " + str(self.people) + " persons recorded.")
    

    def add_person(self, name, age, children, spouse):
        """Each persons name, age, children and spouse is added to the data.

        This  gets the name of the person if it exits, it identifies the name of the person and says it is present.
        If the name doesnt exist, the age, spouse and children is added to the list.
        """
        self.name = name
        if self.name in self.people:
            raise NameError(self.name, " already present")
        else:
            self.people[self.name] = PersonData(age, spouse, children).__dict__
        

    def print_pop(self):
        print("%s,%10s,%10s,%10s" % ("Name", "Age", "Children", "Spouse"))
        """Prints the name, age, children, and spouse with 10 spaces in between. 

        This checks the name, age, children, and spouse of the person and place them in rows and columns created. 
        """
        for self.name in self.people:
            if self.name:
                person_data = self.people[self.name]
                print(
                    "%s,%10s,%10s,%10s" %
                    (self.name,
                     person_data["age"],
                        person_data["children"],
                        person_data["spouse"]))

    def remove_person(self, name):
        """This removes a persons name from the list in the data.

        If the persons name is deleted or not in the list, a NameError of the removed person is identified 
        it shows that the person is not present.
        """
        self.name = name
        if self.name in self.people:
            del self.people[self.name]
        else:
            raise NameError("remove_person: " + self.name, " not present")


if __name__ == "__main__":
    """Sample output to run with PersonData."""
    p1 = Population()
    print(p1)
    p1.add_person("Ed", 47, 2, "Pam")
    p1.add_person("Pam", 51, 2, "Ed")
    print(p1.print_pop())
    p1.remove_person("Ed")
    p1.remove_person("Pam")
    print(p1)
    # p1.remove_person("Ed")
    p1.add_person("Ed", 47, 2, "Pam")
    #p1.add_person("Ed", 47, 2 , "Pam")
    print(p1)
